# Verifier
A sample verifier app which authenticates data sent by Resident app
